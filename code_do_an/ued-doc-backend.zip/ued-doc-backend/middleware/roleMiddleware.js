const checkRole = (allowedRoles) => {
    return (req, res, next) => {
        if (!req.user || !allowedRoles.includes(req.user.role)) {
            return res.status(403).json({ 
                success: false, 
                message: 'Truy cập bị từ chối! Bạn không có quyền thực hiện thao tác này.' 
            });
        }
        next();
    };
};

module.exports = checkRole;
